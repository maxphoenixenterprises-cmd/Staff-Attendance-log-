import { PrismaClient } from "@prisma/client";
import bcrypt from "bcrypt";
const prisma = new PrismaClient();
async function main() {
  const hash = await bcrypt.hash("password123", 10);
  await prisma.employee.create({
    data: {
      employeeId: "EMP001",
      firstName: "Admin",
      lastName: "User",
      email: "admin@example.com",
      password: hash,
      role: "admin"
    }
  });
  await prisma.employee.createMany({
    data: [
      { employeeId: "EMP002", firstName: "John", lastName: "Doe", email: "john@example.com", password: hash, role: "employee" },
      { employeeId: "EMP003", firstName: "Mary", lastName: "Smith", email: "mary@example.com", password: hash, role: "employee" }
    ]
  });
  console.log("✅ Seed completed");
}
main().then(() => prisma.$disconnect()).catch(e => { console.error(e); prisma.$disconnect(); });
