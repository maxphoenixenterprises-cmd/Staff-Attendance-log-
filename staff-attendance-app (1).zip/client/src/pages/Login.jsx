import { useState } from "react";
import api from "../services/api";
export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const res = await api.post("/auth/login", { email, password });
      localStorage.setItem("token", res.data.token);
      alert("Login successful!");
    } catch {
      alert("Invalid credentials");
    }
  };
  return (
    <div className="h-screen flex items-center justify-center bg-gray-100">
      <form onSubmit={handleLogin} className="p-6 bg-white rounded-2xl shadow-xl w-80">
        <h2 className="text-xl font-bold mb-4 text-center">Staff Login</h2>
        <input type="email" placeholder="Email" className="w-full mb-3 p-2 border rounded" value={email} onChange={(e) => setEmail(e.target.value)} />
        <input type="password" placeholder="Password" className="w-full mb-4 p-2 border rounded" value={password} onChange={(e) => setPassword(e.target.value)} />
        <button className="w-full bg-black text-white p-2 rounded hover:bg-gold">Login</button>
      </form>
    </div>
  );
}
